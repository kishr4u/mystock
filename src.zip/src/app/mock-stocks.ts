import { Stock } from './stock';

export const STOCKS: Stock[] = [
  { id: 11, name: 'MCRO' },
  { id: 12, name: 'IBM' },
  { id: 13, name: 'ORCL' },
  { id: 14, name: 'INFY' },
  { id: 15, name: 'CTS' },
  { id: 16, name: 'TCS' }
  { id: 17, name: 'WIPRO' },
  { id: 18, name: 'PWC' },
  { id: 19, name: 'GLDMN' },
  { id: 20, name: 'OFSS' }
];