export interface Stock {
    id: number;
    name: string;
  }